import { useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";
import { problems } from "./data/problems";
import { variableGuides } from "./data/guides";
import GeneralStrategyExplorer from "./components/GeneralStrategyExplorer";
import CodePractice from "./components/CodePractice";
import ProblemStage from "./interactions/registry";
import { ButtonRuleExplorer } from "./interactions/ButtonInteractions";

export default function App(){
  const [selected,setSelected]=useState("A");
  const [stage,setStage]=useState(0);
  const [choice,setChoice]=useState<number|null>(null);
  const [hint,setHint]=useState(false);
  const [revealed,setRevealed]=useState(false);
  const [done,setDone]=useState<string[]>([]);
  const p=useMemo(()=>problems.find(x=>x.id===selected)!,[selected]);
  useEffect(()=>{queueMicrotask(()=>{try{setDone(JSON.parse(localStorage.getItem("koi-progress")||"[]"))}catch{}})},[]);
  function selectProblem(id:string){setSelected(id);setStage(0);setChoice(null);setHint(false);setRevealed(false)}
  function finish(){const next=[...new Set([...done,p.id])];setDone(next);localStorage.setItem("koi-progress",JSON.stringify(next))}
  const stages=["요구 찾기","작은 예","핵심 질문","규칙 발견","해결 전략","코드 확인"];
  return <main>
    <header className="topbar"><a className="brand"><span>KOI</span> Python Lab</a><div className="progress-mini"><b>{done.length}</b>/15 완료</div></header>
    <section className="hero">
      <div><p className="eyebrow">코드보다 생각이 먼저!</p><h1>파이썬 문제 해결 <em>놀이터</em></h1><p>그림을 움직이고, 작은 예를 시험하고, 질문에 답하면서<br/>정답 코드를 스스로 만들어 보세요.</p></div>
      <div className="hero-card"><div className="route">{stages.map((s,i)=><span key={s} className={i===stage?"now":i<stage?"past":""}>{i+1}</span>)}</div><strong>{stages[stage]}</strong><small>한 단계씩 생각의 계단을 올라가요</small></div>
    </section>
    <section className="workspace">
      <aside>
        <div className="aside-title"><b>문제 지도</b><span>{Math.round(done.length/15*100)}%</span></div>
        <div className="map">{problems.map(x=><button key={x.id} onClick={()=>selectProblem(x.id)} className={`${selected===x.id?"active":""} ${done.includes(x.id)?"done":""}`} style={{"--accent":x.color} as CSSProperties}><span>{done.includes(x.id)?"✓":x.id}</span><div><b>{x.title}</b><small>{x.tags.join(" · ")}</small></div></button>)}</div>
      </aside>
      <article className="lab" style={{"--accent":p.color} as CSSProperties}>
        <div className="problem-head"><span className="letter">{p.id}</span><div><p>문제 {p.id}</p><h2>{p.title}</h2></div><div className="tags">{p.tags.map(t=><span key={t}>{t}</span>)}</div></div>
        <nav className="stage-nav">{stages.map((s,i)=><button key={s} onClick={()=>i<=stage&&setStage(i)} className={i===stage?"active":i<stage?"done":""}><i>{i<stage?"✓":i+1}</i>{s}</button>)}</nav>
        <div className="stage-body">
          {stage===0&&<><div className="mission"><span>이번 문제의 할 일</span><h3>{p.story}</h3></div><div className="io-cards"><button onClick={()=>setChoice(0)}><span>컴퓨터가 받는 값</span><b>{p.input}</b></button><button onClick={()=>setChoice(1)}><span>컴퓨터가 보여 줄 답</span><b>{p.output}</b></button></div><p className="coach">💬 먼저 “무엇을 답으로 보여 줘야 하지?”를 자기 말로 설명해 보세요.</p></>}
          {stage===1&&<ProblemStage key={p.id} problem={p}/>}
          {stage===2&&<div className="question-card"><span>생각 질문</span><h3>{p.question}</h3><div className="choices">{p.choices.map((c,i)=><button key={c} onClick={()=>setChoice(i)} className={choice===i?(i===p.correct?"correct":"wrong"):""}>{c}{choice===i&&<i>{i===p.correct?"맞았어요!":"다시 생각해 볼까요?"}</i>}</button>)}</div><button className="hint-btn" onClick={()=>setHint(!hint)}>💡 {hint?"힌트 닫기":"힌트 보기"}</button>{hint&&<p className="hint">{p.hint}</p>}</div>}
          {stage===3&&<div className="insight"><div className="spark">✦</div><p>작은 예에서 발견한 규칙</p><h3>{p.insight}</h3><textarea placeholder="내가 발견한 규칙을 먼저 적어 보세요…" /><small>정답을 외우기보다, 왜 이런 규칙이 생기는지 그림을 다시 보세요.</small></div>}
          {stage===4&&(p.id==="O"?<ButtonRuleExplorer/>:<GeneralStrategyExplorer key={p.id} p={p}/>)}
          {stage===5&&<div className="code-stage"><CodePractice key={p.id} problemId={p.id} onPass={finish}/><div className="example-divider"><span>또는</span></div><div className="code-gate"><div><span>막힐 때 비교하는 여러 풀이 중 하나</span><h3>가장 쉬운 풀이 예시를 볼까요?</h3></div><button onClick={()=>setRevealed(!revealed)}>{revealed?"코드 가리기":"풀이 예시 열기"}</button></div>{revealed?<><div className="many-answers-note"><b>이 코드만 정답은 아니에요.</b><p>다른 코드를 써도 모든 입력에서 알맞은 답이 나오면 정답이 될 수 있어요. 먼저 내가 생각한 방법과 비교해 보세요.</p></div><div className="variable-guide"><span>이름표 먼저 읽기</span>{variableGuides[p.id]?.map(item=>{const [name,meaning]=item.split(" = ");return <div key={item}><code>{name}</code><i>→</i><b>{meaning}</b></div>})}</div><pre><code>{p.code}</code></pre><div className="answer-checklist"><span>다른 풀이도 정답인지 확인하는 법</span><b>① 예제의 답이 맞나요?</b><b>② 작은 수와 큰 수도 맞나요?</b><b>③ 내가 왜 이렇게 썼는지 설명할 수 있나요?</b></div><div className="verify"><span>손으로 검산</span><b>{p.sample}</b></div><button className="complete" onClick={finish}>{done.includes(p.id)?"✓ 이 문제를 완료했어요":"문제 해결 완료하기"}</button></>:<div className="locked"><span>✍️</span><p>먼저 위에서 내 코드를 시험해 보세요. 막히면 풀이 예시를 열어 비교할 수 있어요.</p></div>}</div>}
        </div>
        <div className="actions"><button disabled={stage===0} onClick={()=>setStage(stage-1)}>← 이전</button><span>{stage+1} / 6</span><button className="next" disabled={stage===5||(stage===2&&choice!==p.correct)} onClick={()=>setStage(stage+1)}>{stage===2&&choice!==p.correct?"정답을 찾아야 다음으로 갈 수 있어요":"다음 단계 →"}</button></div>
      </article>
    </section>
    <footer><b>KOISTUDY Python Lab</b><p>정답 코드를 외우지 말고, 왜 이 방법이면 답이 나오는지 설명해 보세요.</p></footer>
  </main>
}
