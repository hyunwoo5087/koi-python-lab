import { useState } from "react";
import { codeTests } from "../data/codeTests";
import { cleanOutput, friendlyError, runPython } from "../lib/pythonRunner";

type TestResult = {
  name: string;
  passed: boolean;
  input: string;
  expected: string;
  actual: string;
  hint: string;
};

type CheckState =
  | { kind: "idle" }
  | { kind: "running"; current: number; total: number }
  | { kind: "passed"; results: TestResult[] }
  | { kind: "failed"; results: TestResult[]; error?: string };

export default function CodePractice({
  problemId,
  onPass,
}: {
  problemId: string;
  onPass: () => void;
}) {
  const [code, setCode] = useState("");
  const [state, setState] = useState<CheckState>({ kind: "idle" });
  const problemTests = codeTests[problemId] ?? [];

  async function checkCode() {
    if (!code.trim()) {
      setState({
        kind: "failed",
        results: [],
        error: "먼저 코드 칸에 내 코드를 쓰거나 붙여 넣어 주세요.",
      });
      return;
    }

    const results: TestResult[] = [];
    setState({ kind: "running", current: 0, total: problemTests.length });

    for (let index = 0; index < problemTests.length; index++) {
      const test = problemTests[index];
      setState({ kind: "running", current: index + 1, total: problemTests.length });
      try {
        const actual = await runPython(code, test.input);
        const passed = actual === cleanOutput(test.expected);
        results.push({ ...test, actual, passed });
        if (!passed) {
          setState({ kind: "failed", results });
          return;
        }
      } catch (error) {
        setState({
          kind: "failed",
          results,
          error: friendlyError(String(error)),
        });
        return;
      }
    }

    setState({ kind: "passed", results });
    onPass();
  }

  const failedResult =
    state.kind === "failed" ? state.results.find((result) => !result.passed) : undefined;

  return (
    <section className="code-practice">
      <div className="practice-title">
        <div>
          <span>내 코드 실험실</span>
          <h3>내가 만든 코드로 시험해 볼까요?</h3>
          <p>변수 이름이나 풀이 순서가 달라도, 모든 시험의 답이 맞으면 정답이에요.</p>
        </div>
        <small>🔒 이 브라우저에서만 실행 · 저장하거나 보내지 않음</small>
      </div>

      <label className="code-editor">
        <span>파이썬 코드 직접 쓰기 또는 붙여넣기</span>
        <textarea
          value={code}
          onChange={(event) => {
            setCode(event.target.value);
            setState({ kind: "idle" });
          }}
          spellCheck={false}
          autoCapitalize="off"
          autoCorrect="off"
          placeholder={"# 여기에 내 코드를 써 보세요.\n# 예: n = int(input())"}
          aria-label="내 파이썬 코드"
        />
      </label>

      <div className="practice-actions">
        <button
          className="run-code"
          onClick={checkCode}
          disabled={state.kind === "running"}
        >
          {state.kind === "running"
            ? `시험 중 ${state.current}/${state.total}`
            : "▶ 내 코드 시험하기"}
        </button>
        <button
          className="clear-code"
          onClick={() => {
            setCode("");
            setState({ kind: "idle" });
          }}
          disabled={!code}
        >
          모두 지우기
        </button>
      </div>

      <div className="test-dots" aria-label="코드 시험 결과">
        {problemTests.map((test, index) => {
          const result =
            state.kind === "passed" || state.kind === "failed"
              ? state.results[index]
              : undefined;
          const running =
            state.kind === "running" && state.current === index + 1;
          return (
            <span
              key={test.name}
              className={
                result ? (result.passed ? "pass" : "fail") : running ? "running" : ""
              }
            >
              {result ? (result.passed ? "✓" : "×") : running ? "…" : index + 1}
              <b>{test.name}</b>
            </span>
          );
        })}
      </div>

      <div className="check-message" aria-live="polite">
        {state.kind === "idle" && (
          <p>코드를 시험하면 예제뿐 아니라 다른 작은 수도 함께 확인해요.</p>
        )}
        {state.kind === "running" && (
          <p>입력 {state.current}번을 넣어 코드를 실행하고 있어요…</p>
        )}
        {state.kind === "passed" && (
          <div className="pass-message">
            <strong>🎉 모든 시험을 통과했어요!</strong>
            <p>예시 코드와 달라도 괜찮아요. 같은 문제를 올바르게 해결한 내 코드예요.</p>
          </div>
        )}
        {state.kind === "failed" && state.error && (
          <div className="error-message">
            <strong>코드를 실행하지 못했어요</strong>
            <p>{state.error}</p>
          </div>
        )}
        {failedResult && (
          <div className="wrong-answer">
            <strong>{failedResult.name} 시험에서 답이 달라요</strong>
            <div>
              <span>
                넣은 값
                <code>{failedResult.input.trim()}</code>
              </span>
              <span>
                나와야 할 답
                <code>{failedResult.expected}</code>
              </span>
              <span>
                내 코드의 답
                <code>{failedResult.actual || "(아무것도 출력되지 않음)"}</code>
              </span>
            </div>
            <p>💡 {failedResult.hint}</p>
          </div>
        )}
      </div>
    </section>
  );
}
